<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>My Dynamic Site</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Welcome to My Site</h1>
    <form action="submit.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <textarea name="message" placeholder="Your Message" required></textarea><br>
        <button type="submit">Submit</button>
    </form>

    <h2>Messages:</h2>
    <?php
    $result = $conn->query("SELECT * FROM messages ORDER BY id DESC");
    while($row = $result->fetch_assoc()) {
        echo "<p><strong>{$row['name']}:</strong> {$row['message']}</p>";
    }
    ?>
</body>
</html>
